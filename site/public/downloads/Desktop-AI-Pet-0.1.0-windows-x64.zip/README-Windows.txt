Desktop AI Pet for Windows

1. Unzip this archive.
2. Run "Desktop AI Pet.exe".
3. Import the adoption.pet file from the adoption site on first launch.

Windows WebView2 Runtime is required. Most current Windows 10/11 machines already include it.
